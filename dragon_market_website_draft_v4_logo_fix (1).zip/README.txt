DRAGON MARKET — Website Draft 3 — Logo Fix

Files:
- index.html: complete responsive storefront (HTML/CSS/JavaScript in one file).
- dragon-logo.jpg: new black/silver/purple Dragon Market Emblem logo artwork. The HTML uses a relative ./dragon-logo.jpg path; keep the image in the same folder as index.html.

Updated from your feedback:
- Uses your dragon logo artwork.
- Discord-only contact; no WhatsApp.
- Discord invite: https://discord.gg/sBGPpRnV3
- Backup contact IGNs: Askari1214 and _cinoxicxd
- Marketplace categories from your screenshot: MCFA-STORE, MC-REDEEMCODE, NITRO-STORE, SPOTIFY-PREMIUM, NETFLIX-STORE, CRUNCHYROLL, FIREMC-MONEY, FREEFIRE-ACCOUNT, M3MBERS, DONUTSMP-MONEY.
- Search and category filters work in-browser. Product enquiries open your Discord invite.

Deploy to GitHub Pages:
1. Extract this ZIP.
2. Upload index.html and dragon-logo.jpg together to the repository root (do not upload only index.html). The ZIP has both files at its top level for easy upload.
3. Open repository Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Open the published site link shown in Pages settings.

This is a static frontend. It does not take payments or store orders.
